package com.adobe.webserver;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * This Class declares the general and HTTP constants and defines general static
 * methods:
 */

class Constants {

	/** 2XX: generally "OK" */
	public static final int HTTP_OK = 200;
	public static final int HTTP_CREATED = 201;
	public static final int HTTP_ACCEPTED = 202;
	public static final int HTTP_NOT_AUTHORITATIVE = 203;
	public static final int HTTP_NO_CONTENT = 204;
	public static final int HTTP_RESET = 205;
	public static final int HTTP_PARTIAL = 206;

	/** 3XX: relocation/redirect */
	public static final int HTTP_MULT_CHOICE = 300;
	public static final int HTTP_MOVED_PERM = 301;
	public static final int HTTP_MOVED_TEMP = 302;
	public static final int HTTP_SEE_OTHER = 303;
	public static final int HTTP_NOT_MODIFIED = 304;
	public static final int HTTP_USE_PROXY = 305;

	/** 4XX: client error */
	public static final int HTTP_BAD_REQUEST = 400;
	public static final int HTTP_UNAUTHORIZED = 401;
	public static final int HTTP_PAYMENT_REQUIRED = 402;
	public static final int HTTP_FORBIDDEN = 403;
	public static final int HTTP_NOT_FOUND = 404;
	public static final int HTTP_BAD_METHOD = 405;
	public static final int HTTP_NOT_ACCEPTABLE = 406;
	public static final int HTTP_PROXY_AUTH = 407;
	public static final int HTTP_CLIENT_TIMEOUT = 408;
	public static final int HTTP_CONFLICT = 409;
	public static final int HTTP_GONE = 410;
	public static final int HTTP_LENGTH_REQUIRED = 411;
	public static final int HTTP_PRECON_FAILED = 412;
	public static final int HTTP_ENTITY_TOO_LARGE = 413;
	public static final int HTTP_REQ_TOO_LONG = 414;
	public static final int HTTP_UNSUPPORTED_TYPE = 415;

	/** 5XX: server error */
	public static final int HTTP_SERVER_ERROR = 500;
	public static final int HTTP_INTERNAL_ERROR = 501;
	public static final int HTTP_BAD_GATEWAY = 502;
	public static final int HTTP_UNAVAILABLE = 503;
	public static final int HTTP_GATEWAY_TIMEOUT = 504;
	public static final int HTTP_VERSION = 505;

	/* the Web server's virtual root directory */
	public static File root;

	static PrintStream log = null;

	/*
	 * Configuration information of the Web server is present in this props
	 * object
	 */
	protected static Properties props = new Properties();

	/* timeout on client connections */
	static int timeout = 0;

	/* maximum number of worker threads */
	static int workerThreads = 5;
	static boolean mozillaClient = false;

	/* General method for printing strings */
	static void printString(String s) {
		System.out.println(s);
	}

	/* print logs to the log file */
	static void log(String s) {
		synchronized (log) {
			log.println(s);
			log.flush();
		}
	}

	/* print to the log file */
	static void printProperties() {

		printString("\n");
		printString("# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #");
		printString("\n");
		printString("Web Server can be accessed on Port : " + WebServer.port);
		printString("Web server's virtual root directory : " + root);
		printString("Timeout on client connections in milliseconds : " + timeout);
		printString("Number of Worker Threads : " + workerThreads);
		printString("\n");
		printString("# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #");
		printString("\n\n");
		printString("************************WEBSERVER STARTED SUCCESSFULLY************************\n");

	}

	/* load server.properties from java.home */
	static void loadServerConfigurationProperties() throws IOException {
		File f = new File(System.getProperty("java.home") + "\\lib\\" + "server.properties");

		if (f.exists()) {
			InputStream is = new BufferedInputStream(new FileInputStream(f));

			props.load(is);
			is.close();
			String r = props.getProperty("root");

			if (r != null) {
				root = new File(r);
				if (!root.exists()) {
					throw new Error(root + " Server Root Directory does not exist");
				}
			}

			r = props.getProperty("timeout");
			if (r != null) {
				timeout = Integer.parseInt(r);
			}
			r = props.getProperty("workerThreads");
			if (r != null) {
				workerThreads = Integer.parseInt(r);
			}
			r = props.getProperty("log");
			if (r != null) {
				log = new PrintStream(new BufferedOutputStream(new FileOutputStream(r)));
			}
		}

		/*
		 * Assign default values to root, timeout, workerThreads and log if the
		 * same have not been specified in the server.propwerties file
		 */

		if (root == null) {
			root = new File(System.getProperty("user.dir")).getParentFile();
		}
		if (timeout <= 1000) {
			timeout = 5000;
		}
		if (workerThreads > 25) {
			printString("\n");
			printString("#####################################################################");
			printString("\n");
			printString("Too many Threads!!!Maximum number of Worker Threads can be 15 only");
			printString("\n");
			printString("#####################################################################");
			workerThreads = 15;
		}
		if (log == null) {
			log = System.out;
		}
	}
}