package com.adobe.webserver;

import java.io.IOException;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;

/* 
The ThreadPool class contains a Vector of WorkerThread objects.
These objects are the individual threads that make up the pool. 
The WorkerThread objects will start at the time of their construction.
If there are more HTTP requests than there are WorkerThreads, 
the extra requests will backlog until WorkerThreads free up. 
*/

class ThreadPool extends WebServer {

	String[] s = new String[workerThreads];

	void createThreadPool() {

		for (int i = 1; i <= workerThreads; ++i) {
			Worker w = new Worker();
			Thread t = new Thread(w, "Worker Thread No." + i);
			t.start();

			threads.addElement(w);
		}
		try {
			ServerSocket serversocket = new ServerSocket(port);

			do {

				Socket socket = serversocket.accept();
				System.out.println(socket);
				System.out.println(socket.getPort());

				Worker w = null;
				synchronized (threads) {
					if (threads.isEmpty()) {

					} else {
						w = (Worker) threads.elementAt(0);
						threads.removeElementAt(0);
						w.setSocket(socket);
					}
				}
			} while (true);
		} catch (BindException be) {

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
