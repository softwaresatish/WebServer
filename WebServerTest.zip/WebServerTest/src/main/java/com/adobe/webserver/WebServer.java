package com.adobe.webserver;

import java.util.Vector;

public class WebServer extends Constants {

	/* Specifying Default port for listening the requests */
	public static int port = 8000;

	/*
	 * The Vector class implements an array of objects which is able to grow. It
	 * contains components that can be accessed using an integer index. The size
	 * of a Vector can grow or shrink as needed to accommodate adding and
	 * removing items after the Vector has been created. The workerThreads are
	 * added to the Vector object threads where the worker threads stand idle
	 * Vector is used since it is synchronized
	 */

	static Vector threads = new Vector();

	public static void main(String[] userSpecifiedPort) throws Exception {
		if (userSpecifiedPort.length > 0) {
			port = Integer.parseInt(userSpecifiedPort[0]);
		}
		loadServerConfigurationProperties();
		printProperties();

		/*
		 * Instantiate ThreadPoool class and call the createThreadPool() method
		 * on threadPool object
		 */
		ThreadPool threadPool = new ThreadPool();
		threadPool.createThreadPool();
	}
}