package com.adobe.webserver;

import java.io.BufferedInputStream;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Date;
import java.util.Vector;

class Worker extends WebServer implements Runnable {

	static final byte[] EOL = { (byte) '\r', (byte) '\n' };

	final static int BUFFER_SIZE = 2048;
	/*
	 * A byte array buffer to read and write files. Memory is allocated to it
	 * once in the constructor of the class Worker and reused thereafter.
	 */
	byte[] buffer;
	/* Socket for the client being handled */
	private Socket socket;

	String serverHeaderInfo = null;
	int countClient = 0;

	Worker() {
		buffer = new byte[BUFFER_SIZE];
		socket = null;
	}

	synchronized void setSocket(Socket socket) {
		this.socket = socket;
		notify();
	}

	public synchronized void run() {
		do {
			if (socket == null) {

				try {
					wait();
				} catch (InterruptedException e) {
					continue;
				}
			}
			try {
				handleClientRequest();
			} catch (Exception e) {
				e.printStackTrace();
			}

			socket = null;
			Vector pool = WebServer.threads;
			synchronized (pool) {
				/*
				 * When the request is complete add the worker thread back into
				 * the pool
				 */
				pool.addElement(this);
			}
		} while (true);
	}

	void handleClientRequest() throws IOException {
		InputStream is = new BufferedInputStream(socket.getInputStream());
		PrintStream ps = new PrintStream(socket.getOutputStream());
		/*
		 * we will only block in read for this many milliseconds before we fail
		 * with java.io.InterruptedIOException, at which point we will close the
		 * connection.
		 */
		socket.setSoTimeout(WebServer.timeout);
		socket.setTcpNoDelay(true);

		/* Refresh the buffer */
		for (int i = 0; i < BUFFER_SIZE; i++) {
			buffer[i] = 0;
		}
		try {
			/* Limiting support to HTTP GET/HEAD */
			int readBuffer = 0, r = 0;
			boolean endOfLine = false;

			while (readBuffer < BUFFER_SIZE) {
				r = is.read(buffer, readBuffer, BUFFER_SIZE - readBuffer);
				if (r == -1) {
					/* EOF */
					return;
				}
				int i = readBuffer;
				readBuffer += r;
				for (; i < readBuffer; i++) {
					if (buffer[i] == (byte) '\n' || buffer[i] == (byte) '\r') {
						/* read one line */
						endOfLine = true;
						break;
					}
				}

				if (endOfLine) {
					break;
				}
			}

			/* Checking for a GET or a HEAD */
			boolean doingGet;
			/* beginning of file name */
			int index;
			if (buffer[0] == (byte) 'G' && buffer[1] == (byte) 'E' && buffer[2] == (byte) 'T'
					&& buffer[3] == (byte) ' ') {
				doingGet = true;
				index = 4;
			} else if (buffer[0] == (byte) 'H' && buffer[1] == (byte) 'E' && buffer[2] == (byte) 'A'
					&& buffer[3] == (byte) 'D' && buffer[4] == (byte) ' ') {
				doingGet = false;
				index = 5;
			} else {
				/* This method is not supported */
				ps.print("HTTP/1.0 " + HTTP_BAD_METHOD + " unsupported method type: ");
				ps.write(buffer, 0, 5);
				ps.write(EOL);
				ps.flush();
				socket.close();
				return;
			}

			int i = 0;
			/*
			 * find the file name, from: GET
			 */
			for (i = index; i < readBuffer; i++) {
				if (buffer[i] == (byte) ' ') {
					break;
				}
			}

			/*
			 * Reading the client capabilities exposed through its request
			 * header
			 */
			countClient += 1;
			String resquestHeaderInfo = null;
			resquestHeaderInfo = (new String(buffer));
			serverHeaderInfo = resquestHeaderInfo;
			System.out.println("resquestHeaderInfo >>>>>>" + resquestHeaderInfo);
			String ClientInfo;
			// boolean sameClient=false;
			if (resquestHeaderInfo.indexOf("Referer:") != -1) {
				ClientInfo = resquestHeaderInfo.substring(resquestHeaderInfo.indexOf("Referer:"),
						resquestHeaderInfo.indexOf("Referer:") + 22);
				System.out.println("*************************Same Client************************");
				System.out.println("*************************ClientInfo************************   " + ClientInfo);

			} else {
				System.out.println("*********************New Client*************************");
			}
			String connectionInfo = null;
			if (resquestHeaderInfo.indexOf("keep-alive") != -1) {
				connectionInfo = resquestHeaderInfo.substring(resquestHeaderInfo.indexOf("keep-alive"),
						resquestHeaderInfo.indexOf("keep-alive") + 10);
			} else {
				if (resquestHeaderInfo.indexOf("Keep-Alive") != -1) {
					connectionInfo = resquestHeaderInfo.substring(resquestHeaderInfo.indexOf("Keep-Alive"),
							resquestHeaderInfo.indexOf("Keep-Alive") + 10);
				}
			}
			String clientInfo = null;

			if (resquestHeaderInfo.indexOf("Mozilla/5.0") != -1) {
				clientInfo = resquestHeaderInfo.substring(resquestHeaderInfo.indexOf("Mozilla/5.0"),
						resquestHeaderInfo.indexOf("Mozilla/5.0") + 11);
				mozillaClient = true;

			} else {
				mozillaClient = false;
			}
			@SuppressWarnings("deprecation")
			String filename = (new String(buffer, 0, index, i - index)).replace('/', File.separatorChar);

			if (filename.startsWith(File.separator)) {
				filename = filename.substring(1);
			}
			File targ = new File(WebServer.root, filename);
			if (targ.isDirectory()) {
				File ind = new File(targ, "index.html");
				if (ind.exists()) {
					targ = ind;
				}
			}
			boolean fileFound = printHeaders(targ, ps);
			if (doingGet) {
				if (fileFound) {
					sendResponseFile(targ, ps);
				} else {
					fileNotFound(targ, ps);
				}
			}

			/* If the request header has */
			if (!connectionInfo.equalsIgnoreCase("keep-alive")) {
				socket.close();

			} else {

				socket.setSoTimeout(10000);

			}
			if (mozillaClient) {
				socket.setSoTimeout(10000);

			} else {
				socket.close();
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	boolean printHeaders(File targ, PrintStream ps) throws IOException {
		boolean ret = false;
		int responseStatusCode = 0;
		if (!targ.exists()) {
			responseStatusCode = HTTP_NOT_FOUND;
			ps.print("HTTP/1.0 " + HTTP_NOT_FOUND + " not found");
			ps.write(EOL);
			ret = false;
		} else {
			responseStatusCode = HTTP_OK;
			ps.print("HTTP/1.0 " + HTTP_OK + " OK");
			ps.write(EOL);
			ret = true;
		}
		log("From " + socket.getInetAddress().getHostAddress() + ": GET " + targ.getAbsolutePath() + "-->"
				+ responseStatusCode);
		ps.print("Server ");
		ps.write(EOL);
		ps.print("Date: " + (new Date()));
		ps.write(EOL);
		if (ret) {
			if (!targ.isDirectory()) {
				ps.print("Content-length: " + targ.length());
				ps.write(EOL);
				ps.print("Last Modified: " + (new Date(targ.lastModified())));
				ps.write(EOL);
				String name = targ.getName();
				int ind = name.lastIndexOf('.');
				String ct = null;
				if (ind > 0) {
					ct = (String) map.get(name.substring(ind));
				}
				if (ct == null) {
					ct = "unknown/unknown";
				}
				ps.print("Content-type: " + ct);
				ps.write(EOL);
			} else {
				ps.print("Content-type: text/html");
				ps.write(EOL);
			}
		}
		return ret;
	}

	void fileNotFound(File targ, PrintStream ps) throws IOException {

		ps.write(EOL);
		ps.write(EOL);
		ps.println("The requested file could not be found.\n");
	}

	void sendResponseFile(File targ, PrintStream ps) throws IOException {

		InputStream is = null;
		ps.write(EOL);
		if (targ.isDirectory()) {
			;
			listDirectory(targ, ps);
			return;
		} else {
			is = new FileInputStream(targ.getAbsolutePath());
		}

		try {
			int n;
			while ((n = is.read(buffer)) > 0) {
				ps.write(buffer, 0, n);
			}
		} finally {
			is.close();
		}
	}

	/* mapping file extensions to content-types */
	static java.util.Hashtable map = new java.util.Hashtable();

	void listDirectory(File dir, PrintStream ps) throws IOException {

		ps.println("<TITLE>Multithreaded Webserver</TITLE><P>");
		ps.println("<html><body align=center>");
		ps.println("<center><h3><font color=#9999CC>Simple File Based MultiThreaded WebServer</font></h3></center>");
		ps.println("<table  border=1 align=center>");
		ps.println("<tr  bgcolor=#9999CC><td width=30% height=30% align=center><h3>Directory Listing</h3></td>");
		ps.println("<td width=20% height=20% align=center><h3>Creation Date</h3></td>");
		ps.println("<td width=20% height=20% align=center><h3>Last Modified</h3></td>");
		ps.println("<td width=20% height=20% align=center><h3>Last Accessed</h3></td>");
		ps.println("<td width=15% height=15% align=center><h3>Type</h3></td>");

		String[] list = dir.list();

		for (int i = 0; list != null && i < list.length; i++) {

			File f = new File(dir, list[i]);

			Path p = Paths.get(f.getPath());
			BasicFileAttributes fAttr = Files.readAttributes(p, BasicFileAttributes.class);
			if (f.isDirectory()) {
				ps.println("<tr><td>");
				ps.println("<font size=\"" + "2" + "\"face=\"" + "Verdana" + "\">&nbsp;&nbsp;&nbsp;&nbsp;<A HREF=\""
						+ list[i] + "/\">" + list[i] + "</A></font>\n<BR>");
				ps.println("</td>");
				ps.println("<td>" + fAttr.creationTime() + "</td>");
				ps.println("<td>" + fAttr.lastModifiedTime() + "</td>");
				ps.println("<td>" + fAttr.lastAccessTime() + "</td>");
				ps.println("<td align=center><a href=\"" + list[i] + "/\">Folder</a>");
				ps.println("</td");
				ps.println("</tr>");
			} else {
				ps.println("<tr><td>");
				ps.println("<font size=\"" + "2" + "\" face=\"" + "Verdana" + "\">&nbsp;&nbsp;&nbsp;&nbsp;<A HREF=\""
						+ list[i] + "\">" + list[i] + "</A></font><A HREF=\"" + list[i] + "\"></A>\n<BR></td>");
				ps.println("<td>" + fAttr.creationTime() + "</td>");
				ps.println("<td>" + fAttr.lastModifiedTime() + "</td>");
				ps.println("<td>" + fAttr.lastAccessTime() + "</td>");
				ps.println("<td align=center><a href=\"" + list[i] + "/\">File</a>");
				ps.println("</tr>");
			}

		}
		ps.println("</table>");
		ps.println("<P align=left>Web server's virtual root directory : " + root);
		ps.println("<P align=left>Timeout on client connections in milliseconds : " + timeout);
		ps.println("<P align=left>Number of Worker Threads : " + workerThreads);
		ps.println("<P align=left>" + serverHeaderInfo);

		if (serverHeaderInfo.indexOf("Referer:") != -1) {
			String ClientInfo = serverHeaderInfo.substring(serverHeaderInfo.indexOf("Referer:"),
					serverHeaderInfo.indexOf("Referer:") + 22);
			ps.println("<P>*************************ClientInfo************************   " + ClientInfo);

		}

		ps.println("<P><HR><I><font color=blue>" + (new Date()) + "</font></I>");
		ps.println("<I><font color=blue>Copyright @adobeTest</font></I>");
		ps.println("<I><font color=blue>Author Satish Narodey</font></I>");

		ps.println("</body></html>");

	}
}
